CREATE DATABASE IF NOT EXISTS `VENTES` DEFAULT CHARACTER SET UTF8MB4 COLLATE utf8_general_ci;
USE `VENTES`;

CREATE TABLE `BIEN` (
  `id_bien` VARCHAR(42),
  `no_voie` VARCHAR(42),
  `type_voie` VARCHAR(42),
  `voie` VARCHAR(42),
  `total_piece` VARCHAR(42),
  `surface_carrez` VARCHAR(42),
  `surface_local` VARCHAR(42),
  `type_local` VARCHAR(42),
  `#id_codedep_codecommune` VARCHAR(42),
  `id_vente` VARCHAR(42),
  `id_codedep_codecommune` VARCHAR(42),
  PRIMARY KEY (`id_bien`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `COMMUNE` (
  `id_codedep_codecommune` VARCHAR(42),
  `#code_departement` VARCHAR(42),
  `code_commune` VARCHAR(42),
  `code_postal` VARCHAR(42),
  `nom_commune` VARCHAR(42),
  `dep_code` VARCHAR(42),
  PRIMARY KEY (`id_codedep_codecommune`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `DEPARTEMENT` (
  `dep_code` VARCHAR(42),
  `dep_nom` VARCHAR(42),
  `#reg_code` VARCHAR(42),
  `codreg` VARCHAR(42),
  PRIMARY KEY (`dep_code`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `REGION` (
  `codreg` VARCHAR(42),
  `reg_nom` VARCHAR(42),
  `aca_nom` VARCHAR(42),
  `regrp_nom` VARCHAR(42),
  `ptot` VARCHAR(42),
  `pcap` VARCHAR(42),
  `pmun` VARCHAR(42),
  PRIMARY KEY (`codreg`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

CREATE TABLE `VENTE` (
  `id_vente` VARCHAR(42),
  `id_bien` VARCHAR(42),
  `date` VARCHAR(42),
  `valeur` VARCHAR(42),
  PRIMARY KEY (`id_vente`)
) ENGINE=InnoDB DEFAULT CHARSET=UTF8MB4;

ALTER TABLE `BIEN` ADD FOREIGN KEY (`id_codedep_codecommune`) REFERENCES `COMMUNE` (`id_codedep_codecommune`);
ALTER TABLE `BIEN` ADD FOREIGN KEY (`id_vente`) REFERENCES `VENTE` (`id_vente`);
ALTER TABLE `COMMUNE` ADD FOREIGN KEY (`dep_code`) REFERENCES `DEPARTEMENT` (`dep_code`);
ALTER TABLE `DEPARTEMENT` ADD FOREIGN KEY (`codreg`) REFERENCES `REGION` (`codreg`);